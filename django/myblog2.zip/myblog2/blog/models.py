from django.db import models

class PostCategory(models.Model):
    name = models.CharField(max_length=255)
    link_name = models.CharField(max_length=255)


class Post(models.Model):
    title = models.CharField(max_length=255)
    category_name = models.CharField(max_length=255)
    
    content = models.TextField()
    short_content = models.TextField()
    published = models.DateTimeField()
    image = models.ImageField(upload_to='images/')