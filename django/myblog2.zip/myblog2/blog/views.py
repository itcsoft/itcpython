from django.shortcuts import render

# Create your views here.
from .models import Post


def home(request):
    return render(request, 'home.html')


def posts(request):
    posts_lists = Post.objects.all()
    return render(request, 'posts.html', {
        'posts_lists': posts_lists
    })


def post_one(request, post_id):
    post = Post.objects.filter(id=post_id)
    return render(request, 'post_one.html', {
        'post': post.first()
    })